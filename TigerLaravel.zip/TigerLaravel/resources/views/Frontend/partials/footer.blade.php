<!-- Company policy -->
<section>
  <div class="container-fluid contact_area">
    <div class="row">
      <div class="col-md-7">
        <div class="row">
          <div class="col">
            <div class="footer_policy_contact">
              <h6>ABOUT</h6>
              <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Customer Service</a></li>
                <li><a href="#">Carrers</a></li>
                <li><a href="#">ShopBuzz wholesale</a></li>
              </ul>
            </div>
          </div>
          <div class="col">
            <div class="footer_policy_contact">
              <h6>HELP</h6>
              <ul>
                <li><a href="#">Payments</a></li>
                <li><a href="#">Shipping</a></li>
                <li><a href="#">Cancellation & returns</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Report infringement</a></li>
              </ul>
            </div>
          </div>
          <div class="col">
            <div class="footer_policy_contact">
              <h6>POLICY</h6>
              <ul>
                <li><a href="#">Return Policy</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Security</a></li>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">EPR Compliance</a></li>
              </ul>
            </div>
          </div>
          <div class="col">
            <div class="footer_policy_contact">
              <h6>SOCIAL</h6>
              <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">YouTube</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>


        <div class="col-md-5">
          <div class="row">
            <div class="col">
              <div class="footer_policy_contactt">
                <h6>Mail Us</h6>
                <p class="para">Tiger Internet Private Limited,
                  Village: Hatgari, Bibirpukur Bazzer,<br>
                  Tindighi Rood, Narhatta<br>
                  Kahaloo, Bogra,<br>
                  Bangladesh.</p>
              </div>
            </div>
            <div class="col">
              <div class="footer_policy_contactt">
                <h6>DIRECT CONTACT</h6>
                <p>+88 01758152475 <br>
                  +88 01571753265 <br>
                  spirabbi@gmail.com</p>
              </div>

            </div>
          </div>
        </div>

    </div>
  </div>
</section>



<!-- footer copyright -->
<section>
  <div class="container-fluid">
    <div class="row">
      <div class="footer_copyright">
        <p>Online Electronics Store Development(2021) &amp; All rights Reseverd </p>
      </div>
    </div>
  </div>
</section>