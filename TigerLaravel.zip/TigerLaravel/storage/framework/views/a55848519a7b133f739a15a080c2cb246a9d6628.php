<div class="main_department_left">
  <h5>Category</h5>
  <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo route('categories.show', $parent->id); ?>"><span class="arrow"><i class="fas fa-chevron-right"></i> </span><?php echo e($parent->name); ?></a>
  <h6><b></b></h6>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>





<!-- <div class="main_department_left">
  <h5>Department</h5>
  <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a href="<?php echo route('products.show', $parent->id); ?>" data-toggle="collapse"><span class="arrow"><i class="fas fa-chevron-right"></i> </span><?php echo e($parent->name); ?></a>
  <h6><b></b></h6>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div> -->



<!-- main vedio
<div class="list-group">
  <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="#main-<?php echo e($parent->id); ?>" class="list-group-item list-group-item-action" data-toggle="collapse">
      <img src="<?php echo asset('images/categories/'.$parent->image); ?>" width="50">
      <?php echo e($parent->name); ?>

    </a>
    <div class="collapse" id="main-<?php echo e($parent->id); ?>">
      <div class="child-rows">
        <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', $parent->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo route('categories.show', $child->id); ?>" class="list-group-item list-group-item-action">
            <img src="<?php echo asset('images/categories/'.$child->image); ?>" width="30">
            <?php echo e($child->name); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>


    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> -->