<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
    <?php echo $__env->yieldContent('title', 'Tiger'); ?>
    </title>
    <?php echo $__env->make('Frontend.partials.link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>
  <body>
  <!-- header start -->
  <div class="wrapper">
    <?php echo $__env->make('Frontend.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('Frontend.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>
    <!-- footer section -->
    <?php echo $__env->make('Frontend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </div>
    <?php echo $__env->make('Frontend.partials.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- <?php echo $__env->yieldContent('scripts'); ?> -->
  </body>
</html>