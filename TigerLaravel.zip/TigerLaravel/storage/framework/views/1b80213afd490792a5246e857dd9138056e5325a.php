<?php $__env->startSection('content'); ?>
<!-- All Product -->
<section>
  <div class="container-fluid">
    <div class="main_department mt-4 mb-4">  
      <div class="row">
        <div class="col-2">
          <?php echo $__env->make('Frontend.partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-10">
          <div class="department_product">
              <div class="row text-center">
                <?php
                  $products=$category->products()->paginate(9);
                ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4">
                  <div class="img_container">
                    <!-- <img src="<?php echo e(asset('images/products/'. 'product1.jpg')); ?>"> -->
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                      <?php if($i>0): ?>
                      <a href="<?php echo route('products.show', $product->slug); ?>"><img src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="<?php echo e($product->title); ?>"></a>
                      <?php endif; ?>
                    <?php $i--;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="addCart">
                      <form action="<?php echo e(route('carts.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <input type="number" hidden name="product_quantity" value="1">
                        <button type="submit" name="submit" class="btn"><i class="fas fa-shopping-cart"></i></button>
                      </form>
                    </div>
                    
                  </div>
                  <div class="bottom">
                    <a href="<?php echo route('products.show', $product->slug); ?>"><?php echo e($product->title); ?></a>
                    <div class="price">
                      <span>TK <?php echo e($product->price); ?></span>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>

        </div>
      </div>

        </div>
                          <div class="row">
          <div class="pagination">
            <?php echo e($products->links()); ?>

          </div>

<!--         <div class="page_btn">
          <span>1</span>
          <span>2</span>
          <span>3</span>
          <span>4</span>
          <span>&#8594;</span>
        </div> -->



    </div>
  </div>  
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Frontend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>