<?php $__env->startSection('content'); ?>      
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
      <div class="col-xl-12 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
        <div class="card card-statistics">
          <div class="card-header">
            Add Product
          </div>
          <div class="card-body">
            <?php echo $__env->make('backend.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form method="post" action="<?php echo e(route('backend.product.store')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label for="exampleInputEmail1">Title</label>
                <input type="text" name="title" class="form-control">
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1">Description</label>
                <textarea name="description" rows="8" cols="80" class="form-control"></textarea>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Price</label>
                <input type="number" name="price" class="form-control">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail1">Quantity</label>
                <input type="number" name="quantity" class="form-control">
              </div>

              <div class="form-group">
                <label for="exampleInputEmail1">Select Category</label>
                <select class="form-control" name="category_id">
                  <option value="">Please select a category for the product</option>
                  <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parent->id); ?>"><?php echo e($parent->name); ?></option>

                    <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', $parent->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($child->id); ?>"> ------> <?php echo e($child->name); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="exampleInputEmail1">Select Brand</label>
                <select class="form-control" name="brand_id">
                  <option value="">Please select a brand for the product</option>
                  <?php $__currentLoopData = App\Models\Brand::orderBy('name', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

              <div class="form-group">
                <label for="product_image">Product Image</label>
                <!-- for one img inset -->
                <!-- <input type="file" name="product_image" class="form-control"> -->
                <!-- for multiple image insert start -->
                <div class="row">
                  <div class="col-md-4">
                    <input type="file" name="product_image[]" class="form-control">
                  </div>
                  <div class="col-md-4">
                    <input type="file" name="product_image[]" class="form-control">
                  </div>
                  <div class="col-md-4">
                    <input type="file" name="product_image[]" class="form-control">
                  </div>
                  <div class="col-md-4">
                    <input type="file" name="product_image[]" class="form-control">
                  </div>
                  <div class="col-md-4">
                    <input type="file" name="product_image[]" class="form-control">
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Add Product</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->
  <footer class="footer">
    <div class="container-fluid clearfix">
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2021 <a href="http://www.bootstrapdash.com/" target="_blank">Tiger</a>. All rights reserved.</span>
    </div>
  </footer>
  <!-- partial -->
</div>
<!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>