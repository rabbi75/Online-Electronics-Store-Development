    <section>
      <div class="container-fluid">
        <div class="row">
          <div class="main_slider">
            <div class="product-carousel owl-carousel">
              <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div><a href="#"><img src="<?php echo e(asset('images/sliders/'.$slider->image)); ?>" style="height: 300px;"></a>
                  <div class="carousel-caption d-none d-md-block">
                    <h5 style="color:black;"><?php echo e($slider->title); ?></h5>
                    
                    <?php if($slider->button_text): ?>
                      <p>
                        <a href="<?php echo e($slider->button_link); ?>" target="_blank" class="btn btn-danger"><?php echo e($slider->button_text); ?></a>
                      </p>
                    <?php endif; ?>

                  </div>


              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </section>